# LyX-Template für Abschlussarbeiten

Dieses Verzeichnis enthält ein LyX-Template für Abschlussarbeiten. Das Paket wird gepflegt durch Markus Gumbel (m.gumbel@hs-mannheim.de).

Hinweise: Um diese Vorlage zu verwenden, benötigen Sie [LyX](http://www.lyx.org) und eine LaTeX-Installation, die mit Lyx mitinstalliert werden kann. Lyx ist ein Word-ähnlicher Textprozessor, der im Hintergrund LaTeX benutzt. Es lassen sich LaTeX-Fragmente oder -Dokumente in Lyx einzubinden. Damit es möglich, alle Vorteile von LaTeX zu nutzen und (trotzdem) den Text komfortabel zu erfassen.