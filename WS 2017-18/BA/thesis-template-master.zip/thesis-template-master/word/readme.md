# Word-Vorlage für Abschlussarbeiten

In diesem Verzeichnis befindet sich eine Word-Vorlage für Abschlussarbeiten. Sie versucht, die [LaTeX-Vorlage](../latex), soweit dies mit Word möglich ist, nachzuahmen.

Generell hat sich Word nicht unbedingt für das Schreiben von Abschlussarbeiten bewährt. Wenn Sie es sich also zutrauen, sollten Sie die Arbeit lieber mit LaTeX schreiben. Die LaTeX-Version bietet deutlich umfangreicherer Möglichkeiten, insbesondere bei der Literaturverwaltung.
