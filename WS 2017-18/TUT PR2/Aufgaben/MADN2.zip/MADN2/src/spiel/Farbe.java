package spiel;

public enum Farbe {
	ROT,BLAU,GR�N,GELB;
}