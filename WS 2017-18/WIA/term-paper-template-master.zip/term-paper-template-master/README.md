# Template for Term Papers (Seminararbeiten)

## Purpose

This repo contains a LaTeX template for term papers for the students of computer science at the University of Applied Sciences Mannheim.

It is of limited use for people outside the respective university.


## Zweck

Dieses Repository enthält eine LaTeX-Vorlage für Seminararbeiten. Sie richten sich an Studierende der Fakultät für Informatik an der Hochschule Mannheim.

Für Personen außerhalb der Hochschule ist die Vorlage möglicherweise nur von begrenztem Wert.
